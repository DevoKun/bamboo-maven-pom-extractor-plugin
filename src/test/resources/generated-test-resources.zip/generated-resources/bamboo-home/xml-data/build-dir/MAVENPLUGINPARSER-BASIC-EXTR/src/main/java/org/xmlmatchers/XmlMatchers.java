// Generated source.
package org.xmlmatchers;

public class XmlMatchers {

  public static org.hamcrest.Matcher<javax.xml.transform.Source> isEquivalentTo(javax.xml.transform.Source control) {
    return org.xmlmatchers.equivalence.IsEquivalentTo.isEquivalentTo(control);
  }

  public static org.hamcrest.Matcher<javax.xml.transform.Source> equivalentTo(javax.xml.transform.Source control) {
    return org.xmlmatchers.equivalence.IsEquivalentTo.equivalentTo(control);
  }

  public static org.hamcrest.Matcher<javax.xml.transform.Source> hasXPath(java.lang.String xPath, javax.xml.namespace.NamespaceContext namespaceContext) {
    return org.xmlmatchers.xpath.HasXPath.hasXPath(xPath, namespaceContext);
  }

  public static org.hamcrest.Matcher<javax.xml.transform.Source> hasXPath(java.lang.String xPath, org.hamcrest.Matcher<? super java.lang.String> valueMatcher) {
    return org.xmlmatchers.xpath.HasXPath.hasXPath(xPath, valueMatcher);
  }

  public static org.hamcrest.Matcher<javax.xml.transform.Source> hasXPath(java.lang.String xPath, javax.xml.namespace.NamespaceContext namespaceContext, org.hamcrest.Matcher<? super java.lang.String> valueMatcher) {
    return org.xmlmatchers.xpath.HasXPath.hasXPath(xPath, namespaceContext, valueMatcher);
  }

  public static org.hamcrest.Matcher<javax.xml.transform.Source> hasXPath(java.lang.String xPath) {
    return org.xmlmatchers.xpath.HasXPath.hasXPath(xPath);
  }

  public static <T> org.hamcrest.Matcher<javax.xml.transform.Source> hasXPath(java.lang.String xPath, javax.xml.namespace.NamespaceContext namespaceContext, org.xmlmatchers.xpath.XpathReturnType<? super T> xpathReturnType, org.hamcrest.Matcher<? super T> valueMatcher) {
    return org.xmlmatchers.xpath.HasXPath.<T>hasXPath(xPath, namespaceContext, xpathReturnType, valueMatcher);
  }

  public static org.hamcrest.Matcher<javax.xml.transform.Source> hasXPath(java.lang.String xPath, org.hamcrest.Matcher<? super java.lang.String> valueMatcher, javax.xml.namespace.NamespaceContext namespaceContext) {
    return org.xmlmatchers.xpath.HasXPath.hasXPath(xPath, valueMatcher, namespaceContext);
  }

  public static <T> org.hamcrest.Matcher<javax.xml.transform.Source> hasXPath(java.lang.String xPath, org.xmlmatchers.xpath.XpathReturnType<? super T> xpathReturnType, org.hamcrest.Matcher<? super T> valueMatcher) {
    return org.xmlmatchers.xpath.HasXPath.<T>hasXPath(xPath, xpathReturnType, valueMatcher);
  }

  public static org.hamcrest.Matcher<javax.xml.transform.Source> conformsTo(javax.xml.validation.Schema schema) {
    return org.xmlmatchers.validation.ConformsToSchema.conformsTo(schema);
  }

}
